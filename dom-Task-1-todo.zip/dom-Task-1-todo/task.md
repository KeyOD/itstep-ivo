Task: Build a Simple To-Do List Application
Requirements:

1.JavaScript: Add functionality to add pre-defined tasks, mark tasks as completed, and remove tasks.

Event listeners are added to the buttons to add pre-defined tasks to the list when clicked.
Each task is displayed with a "Complete" button to mark it as completed and a "Remove" button to remove it from the list.
The addTask function handles the creation of new tasks and appending them to the task list.