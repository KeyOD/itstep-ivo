const app = () => {

}
window.addEventListener('load', app)
